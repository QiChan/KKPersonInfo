/*
 * 功能：测试Linux C程序,讲解编译链接过程
 * 作者：李涛
 * 创建日期: 2019-9-14
 */
#include <stdio.h>
#include <stdlib.h>

int add(int x, int y) {
	int t = x + y;

	return t;
}

#define zcx main
#define begin {
#define end  }

#define WIN 0

int zcx( void )
begin
	int a = 10;
	int b = 20;
	#include "test"

#if WIN
	printf("windows\n");
#else
	printf("Linux\n");
#endif

	printf("%d+%d=%d\n", a, b, r);
end

