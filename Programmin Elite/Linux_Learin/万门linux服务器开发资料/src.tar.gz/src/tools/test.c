#include <stdio.h>

int main( void ) {
	int num;
	
	scanf("%d", &num);

	printf("num=%d\n", num);
}

