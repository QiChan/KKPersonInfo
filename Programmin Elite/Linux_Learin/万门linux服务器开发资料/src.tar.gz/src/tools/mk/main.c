#include <stdio.h>
#include "add.h"

int main ( void ) {
	int a = 10;
	int b = 20;

	printf("%d+%d=%d\n", a, b, add(a, b));

	return 0;
}
