#include "add.h"

int add( int a, int b ) {
	int r = a + b;

	return r;
}
