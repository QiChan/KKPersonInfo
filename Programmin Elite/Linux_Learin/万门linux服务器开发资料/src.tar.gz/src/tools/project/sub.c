#include "sub.h"

int sub(int x, int y) {

	return x - y;
}
