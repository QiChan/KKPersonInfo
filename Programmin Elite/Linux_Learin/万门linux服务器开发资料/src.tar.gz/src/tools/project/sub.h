#ifndef __SUB_H__
#define __SUB_H__

int sub(int x, int y);

#endif // __SUB_H__

