#include <stdio.h>
#include <stdlib.h>

int feb(int n) {
	if ( n == 1 || n == 0 ) {
		return 1;
	} else {
		return feb(n-1) + feb(n-2);
	}
}

void fun( void ) {
	
	int add(int a, int b) {
		return a + b;
	}
}

int main( void ) {
	// printf("%d\n", add(3, 2));
	int i;
	int arr[10]; 

	arr[0] = 0;
	arr[1] = 1;
	
	for (i=2; i<10; i++) {
		arr[i] = arr[i-1] + arr[i-2];
	}

	int r = feb(9);

	printf("feb(9)=%d\n", r);
	printf("arr[9]=%d\n", arr[9]);

	return 0;
}

