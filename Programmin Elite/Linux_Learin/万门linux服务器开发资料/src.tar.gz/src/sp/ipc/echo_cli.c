#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>

struct msgbuf {
	long channel;
	char mtext[100];
};

int main( void ) {
	int msgid = msgget(12345, 0);
	struct msgbuf mb;
	while ( fgets(mb.mtext+sizeof(pid_t), 100, stdin) != NULL ) {
		mb.channel = 1L;
		*(pid_t*)(mb.mtext) = getpid();
		int len = strlen(mb.mtext+sizeof(pid_t)) + sizeof(pid_t);
		msgsnd(msgid, &mb, len, 0);

		struct msgbuf mbrcv;
		memset(&mbrcv, 0x00, sizeof(mbrcv));
		msgrcv(msgid, &mbrcv, 100, getpid(), 0);
		printf("rcv = %s\n", mbrcv.mtext+sizeof(pid_t));
		memset(&mb, 0x00, sizeof(mb));
	}
}

