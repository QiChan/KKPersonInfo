#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>

union semun {
	int val;
};

void p(int semid) {
	struct sembuf sb[1];
	sb[0].sem_num = 0;
	sb[0].sem_op  = -1;
	sb[0].sem_flg = 0;
	semop(semid, sb, 1);
}

void v(int semid) {
	struct sembuf sb[1];
	sb[0].sem_num = 0;
	sb[0].sem_op  = 1;
	sb[0].sem_flg = 0;
	semop(semid, sb, 1);
}

void setval(int semid, int val) {
	union semun su;
	su.val = val;
	semctl(semid, 0, SETVAL, su);
}

int main( void ) {
	int shmid = shmget(1234, sizeof(int), IPC_CREAT|0644);
	int semidp = semget(1234, 1, IPC_CREAT|0644);
	int semidc = semget(1235, 1, IPC_CREAT|0644);

	srand(getpid());
	setval(semidp, 1);
	setval(semidc, 0);
	int *pi = shmat(shmid, NULL, 0);

	int i = 0;
	while ( 1 ) {
		p(semidp);
		printf("开始生产%d产品\n", i);
		*pi = i++;
		sleep(rand() % 5 + 1);
		printf("生产%d产品结束\n", i);
		v(semidc);
	}
}

