#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>

void p(int semid) {
	struct sembuf sb[1];
	sb[0].sem_num = 0;
	sb[0].sem_op  = -1;
	sb[0].sem_flg = 0;
	semop(semid, sb, 1);
}

void v(int semid) {
	struct sembuf sb[1];
	sb[0].sem_num = 0;
	sb[0].sem_op  = 1;
	sb[0].sem_flg = 0;
	semop(semid, sb, 1);
}

int main( void ) {
	int shmid = shmget(1234, 0, 0);
	int semidp = semget(1234, 0, 0);
	int semidc = semget(1235, 0, 0);

	srand(getpid());

	int *pi = shmat(shmid, NULL, 0);
	int i = 0;
	while ( 1 ) {
		p(semidc);
		i = *pi;
		printf("开始消费%d产品\n", i);
		sleep(rand() % 5 + 1);
		printf("消费%d产品结束\n", i);
		v(semidp);
	}
}

