#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include <signal.h>

int *p = NULL;

void handler( int s ) {
	shmdt(p);
}

int main( void ) {
	struct sigaction act;
	act.sa_handler = handler;
	act.sa_flags = 0;
	sigemptyset(&act.sa_mask);
	
	sigaction(SIGINT, &act, NULL);

	int shmid = shmget(1234, 0, 0);
	p = (int*)shmat(shmid, NULL, 0);

	int i = 1;
	while ( 1 ) {
		sleep(1);
		*p = i++;
	}
}

