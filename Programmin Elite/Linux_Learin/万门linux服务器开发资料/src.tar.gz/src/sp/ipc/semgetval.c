#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/sem.h>

int main( void ) {
	int semid = semget(1234, 0, 0);

	printf("%d\n", semctl(semid, 0, GETVAL, 0));
}

