#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

struct msgbuf {
	long channel;
	char text[100];
};

int main( void ) {
	int msgid = msgget(1234, 0);

	struct msgbuf mb;

	int num;
	printf("input channel:");
	scanf("%d", &num);

	memset(&mb, 0x00, sizeof(mb));
	msgrcv(msgid, &mb, 100, num, 0);
	printf("recv=%s\n", mb.text);
	
}

