#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main( void ) {
	int fds[2];

	pipe(fds);
	pid_t pid = fork();

	if ( pid == 0 ) {
		close(fds[0]);

		sleep(3);
		char *p = "你好，我是子进程\n";
		printf("child before write \n");
		write(fds[1], p, strlen(p));
		printf("child write ok\n");
		close(fds[1]);
	} else {
		close(fds[1]);
		close(fds[0]);
		char buf[100] = {};

		sleep(10);
		printf("parent before read\n");
		//read(fds[0], buf, 100);
		printf("parent read end\n");
		
		printf("read = %s\n", buf);
		close(fds[0]);
	}
}

