#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int main( void ) {
	int msgid = msgget(1234, 0);
	
	msgctl(msgid, IPC_RMID, 0);
}

