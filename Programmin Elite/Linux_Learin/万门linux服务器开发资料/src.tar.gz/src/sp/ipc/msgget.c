#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int main( void ) {
	int msgid = msgget(1234, IPC_CREAT|0644);
	if ( msgid == -1 )
		perror("msgget");
	else
		printf("create msg ok\n");
}

