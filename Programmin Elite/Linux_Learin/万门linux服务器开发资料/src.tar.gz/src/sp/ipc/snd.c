#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

struct msgbuf {
	long channel;
	char text[100];
};

int main( void ) {
	int msgid = msgget(1234, 0);

	struct msgbuf mb;

	printf("input channel:");
	scanf("%d%*c", &mb.channel);
	printf("text:");
	scanf("%[^\n]%*c", mb.text);

	msgsnd(msgid, &mb, strlen(mb.text), 0);
	
}

