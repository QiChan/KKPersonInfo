#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>

int main( void ) {
	int shmid = shmget(1234, sizeof(int), IPC_CREAT|0644);
}

