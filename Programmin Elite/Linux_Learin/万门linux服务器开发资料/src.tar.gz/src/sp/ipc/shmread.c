#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>

int main( void ) {
	int shmid = shmget(1234, 0, 0);
	int *p = (int*)shmat(shmid, NULL, 0);

	int i = 1;
	while ( 1 ) {
		sleep(1);
		printf("%d\n", *p);
	}
}

