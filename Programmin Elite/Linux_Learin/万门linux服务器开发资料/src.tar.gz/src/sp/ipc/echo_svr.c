#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>

struct msgbuf {
	long channel;
	char mtext[100];
};

int main( void ) {
	int msgid = msgget(12345, IPC_CREAT|0644);	
	struct msgbuf mb;

	while ( 1 ) {
		memset(&mb, 0x00, sizeof(mb));
		msgrcv(msgid, &mb, 100, 1, 0);
		mb.channel = *(pid_t*)(mb.mtext);
		int len = strlen(mb.mtext+sizeof(pid_t))+sizeof(pid_t);
		msgsnd(msgid, &mb, len, 0);
	}
}

