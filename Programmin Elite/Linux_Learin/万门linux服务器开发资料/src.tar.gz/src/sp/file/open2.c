#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>

#define E_EXIT(msg) \
	do { 			\
		fprintf(stderr, "[%s][%d]:%s:%s\n", __FILE__, __LINE__, msg, strerror(errno)); \
		exit(EXIT_FAILURE); \
	} while ( 0 )

int main( void ) {
	int fd = open("test1", O_RDWR|O_CREAT|O_EXCL, 0644);
	if ( fd == -1 ) E_EXIT("open");
	char *msg = "welcome to";
	write(fd, msg, strlen(msg));
	close(fd);
}

