#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <pwd.h>
#include <grp.h>
#include <time.h>

int main( int argc, char *argv[] ) {
	if ( argc < 2 ) {
		fprintf(stderr, "usage:%s file\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	struct stat buf;
	if ( stat(argv[1], &buf) == -1 ) {
		perror("stat");
		exit(EXIT_FAILURE);
	}

	char perm[11] = "?---------";
	switch ( buf.st_mode & S_IFMT ) {
		case S_IFSOCK: perm[0] = 's'; break;
		case S_IFLNK:  perm[0] = 'l'; break;
		case S_IFREG:  perm[0] = '-'; break;
		case S_IFBLK:  perm[0] = 'b'; break;
		case S_IFDIR:  perm[0] = 'd'; break;
		case S_IFCHR:  perm[0] = 'c'; break;
		case S_IFIFO:  perm[0] = 'p'; break;
	}
	if ( buf.st_mode&S_IRUSR ) perm[1] = 'r';
	if ( buf.st_mode&S_IWUSR ) perm[2] = 'w';
	if ( buf.st_mode&S_IXUSR ) perm[3] = 'x';
	if ( buf.st_mode&S_IRGRP ) perm[4] = 'r';
	if ( buf.st_mode&S_IWGRP ) perm[5] = 'w';
	if ( buf.st_mode&S_IXGRP ) perm[6] = 'x';
	if ( buf.st_mode&S_IROTH ) perm[7] = 'r';
	if ( buf.st_mode&S_IWOTH ) perm[8] = 'w';
	if ( buf.st_mode&S_IXOTH ) perm[9] = 'x';

	printf("%s ", perm);
	printf("%d ", buf.st_nlink);

	struct passwd *pd = getpwuid(buf.st_uid);
	printf("%s ", pd->pw_name);
	struct group *pg = getgrgid(buf.st_gid);
	printf("%s ", pg->gr_name);

	printf("%d ", buf.st_size);
	
	struct tm *pm = localtime(&buf.st_mtime);
	printf("%02d月-%02d日 %02d:%02d ", 
			pm->tm_mon+1, pm->tm_mday,
			pm->tm_hour, pm->tm_min);

	printf("%s\n", argv[1]);
}

