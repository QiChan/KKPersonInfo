#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>

int main( void ) {
	
	int flags = fcntl(0, F_GETFL, 0);
	
	flags |= O_NONBLOCK;
	fcntl(0, F_SETFL, flags);

	char buf[102] = {};
	int r = read(0, buf, 102);
	if ( r == -1 ) {
		printf("%s\n", strerror(errno));
	} else if ( r > 0 ) {
		printf("%s\n", buf);
	}

}

