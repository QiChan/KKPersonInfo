#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>

#define E_EXIT(msg) \
	do { 			\
		fprintf(stderr, "[%s][%d]:%s:%s\n", __FILE__, __LINE__, msg, strerror(errno)); \
		exit(EXIT_FAILURE); \
	} while ( 0 )

typedef struct stu{
	int id;
	char name[30];
}stu_t;

int main( void ) {
	int num;
	printf("存入几个学生的信息:");
	scanf("%d", &num);

	stu_t s[num];
	int i;
	for (i=0; i<num; i++) {
		printf("%d id:", i+1);
		scanf("%d", &s[i].id);
		printf("name:");
		scanf("%s", &s[i].name);
	}

	int fd = open("stu.dat", O_RDWR|O_CREAT|O_TRUNC, 0644);
	if ( fd == -1 ) E_EXIT("open");
	
	write(fd, &s, sizeof(s));

	close(fd);
}

