#ifndef __GLOBAL_H__
#define __GLOBAL_H__

// 日志等级
#define LOG_EMERG     1 // 紧急
#define LOG_ALERT     2 // 警戒
#define LOG_CRIT      3 // 严重
#define LOG_ERR       4 // 错误
#define LOG_WARN      5 // 警告
#define LOG_NOTICE    6 // 注意
#define LOG_INFO      7 // 消息
#define LOG_DEBUG     8 // 调试

// 处理日志的结构体
typedef struct log_ {
	int fd;
	int level;
}log_t;

// 配置文件key和value
typedef struct conf_ {
	char name[200];
	char content[200];
}conf_t;

// 链表节点
typedef struct node_ {
	conf_t *pconf;
	struct node_ *next;
}node_t;

extern node_t *head;
extern log_t g_log;

node_t *list_insert(node_t *head, conf_t *pconf);
void list_show(node_t *head);
void load(const char *name, node_t **head);
char *get_content(node_t *head, const char *name);
void log_init( void );
void log_info(int level, int err, char *fmt, ...);

#endif 

