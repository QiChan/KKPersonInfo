#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>
#include <time.h>
#include <string.h>
#include <stdarg.h>

#include "global.h"

char levels[9][10] = {
	"",
	"emerg",
	"alert",
	"crit",
	"error",
	"warn",
	"notice",
	"info",
	"debug"
};

log_t g_log;

void log_init( void ) {
	char *name = get_content(head, "log_name");
	g_log.level = atoi(get_content(head, "log_level"));	
	g_log.fd = open(name, O_WRONLY|O_APPEND|O_CREAT, 0644);
} 

void log_info(int level, int err, char *fmt, ...) {
	char buf[1024+1] = {};
	struct timeval tv;
	struct tm      tm;
	int len = 1024;
	int r;
	char *p = buf;

	gettimeofday(&tv, NULL);
	localtime_r(&tv.tv_sec, &tm);

	char curtime[100] = {};
	snprintf(curtime, 100, "%04d-%02d-%02d %02d:%02d:%02d",
			tm.tm_year+1900, tm.tm_mon+1, tm.tm_mday,
			tm.tm_hour, tm.tm_min, tm.tm_sec);	

	r = snprintf(p, len, "%s ", curtime);

	len = len - r;
	p = p + r;
	r = snprintf(p, len, "[%s] ", levels[level]);
	
	len = len - r;
	p = p + r;
	r = snprintf(p, len, " (%d: %s) ", err, strerror(err));
	
	len = len - r;
	p = p + r;

	va_list vp;
	va_start(vp, fmt);
	vsnprintf(p, len, fmt, vp);
	va_end(vp);

	strcat(p, "\n");

	if ( level <= g_log.level )
		write(g_log.fd, buf, strlen(buf));
}


