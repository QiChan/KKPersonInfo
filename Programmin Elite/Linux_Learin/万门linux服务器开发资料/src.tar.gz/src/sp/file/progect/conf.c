#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "global.h"

node_t *list_insert(node_t *head, conf_t *pconf) {
	node_t *p = malloc(sizeof(node_t));
	p->pconf = pconf;
	p->next  = NULL;
	
	if ( head == NULL )
		return p;

	p->next = head;
	return p;
}

void list_show(node_t *head) {
	node_t *cur = head;

	while ( cur != NULL ) {
		printf("name=%s, content=%s\n", cur->pconf->name, cur->pconf->content);
		cur = cur->next;
	}
}

void load(const char *name, node_t **head) {
	FILE *pf = fopen(name, "r");
	if ( pf == NULL )
		return;

	char linebuf[1000];
	while ( !feof(pf) ) {
		memset(linebuf, 0x00, sizeof(linebuf));
		if ( fgets(linebuf, 1000, pf) == NULL )
			continue;
		if ( linebuf[0]=='\n' || linebuf[0]=='#' || linebuf[0]=='[' )
			continue;

		char *p = strchr(linebuf, '=');
		if ( p != NULL ) {
			conf_t *pc = malloc(sizeof(conf_t));
			memcpy(pc->name, linebuf, p-linebuf);
			strcpy(pc->content, p+1);
			pc->content[strlen(pc->content)-1] = 0;
			*head = list_insert(*head, pc);
		}
	}
	
	fclose(pf);
}

char *get_content(node_t *head, const char *name) {
	node_t *cur = head;

	while ( cur != NULL ) {
		if ( strcmp(cur->pconf->name, name) == 0 ) {
			return cur->pconf->content;
		}
		cur = cur->next;
	}

	return NULL;
}

