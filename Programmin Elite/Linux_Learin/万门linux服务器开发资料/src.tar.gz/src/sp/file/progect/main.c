#include <stdio.h>
#include <stdlib.h>
#include "global.h"

node_t *head = NULL;

int main( void ) {
	load("my.conf", &head);

	log_init();
	log_info(5, 4, "my test %s", "欢迎来万门学习Linux服务器开发");
	log_info(1, 2, "my test %s %d %f", "hehe", 123, 4.56);
}

