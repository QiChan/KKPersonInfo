#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

int main( void ) {
	int fd = open("test", O_RDWR);

	struct flock lock;
	lock.l_type   = F_WRLCK;
	lock.l_whence = SEEK_SET;
	lock.l_start  = 0;
	lock.l_len    = 0;

	fcntl(fd, F_SETLKW, &lock);
	printf("lock ok...\n");
	printf("enter any key to unlock\n");
	getchar();
	printf("start unlock\n");
	lock.l_type = F_UNLCK;
	fcntl(fd, F_SETLKW, &lock);

	close(fd);
}

