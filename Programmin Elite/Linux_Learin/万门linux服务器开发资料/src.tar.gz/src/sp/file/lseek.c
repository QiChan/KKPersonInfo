#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

int main(int argc, char *argv[]) {
	int fd = open(argv[1], O_RDWR);

	lseek(fd, 1024*1024*104, SEEK_END);
	write(fd, "a", 1);

	close(fd);
}

