//  读取源文件的内容
//  拷贝到目标文件

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>

#define E_EXIT(msg) \
	do { 			\
		fprintf(stderr, "[%s][%d]:%s:%s\n", __FILE__, __LINE__, msg, strerror(errno)); \
		exit(EXIT_FAILURE); \
	} while ( 0 )

#define BUF_SIZE 1024

// copy src dst
int main( int argc, char *argv[] ) {
	if ( argc != 3  ) {
		fprintf(stderr, "usage:%s src dst\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	int ifd = open(argv[1], O_RDONLY);
	if ( ifd == -1 ) E_EXIT("open src");
	int ofd = open(argv[2], O_WRONLY|O_CREAT, 0666);
	if ( ofd == -1 ) E_EXIT("open dst");

	char buf[BUF_SIZE];
	while ( 1 ) {
		memset(buf, 0x00, sizeof(buf));
		int r = read(ifd, buf, BUF_SIZE);
		if ( r == 0 ) break;
		if ( r == -1 ) E_EXIT("read");
		if ( write(ofd, buf, r) != r ) E_EXIT("write");
	} 

	close(ifd);
	close(ofd);
} 

