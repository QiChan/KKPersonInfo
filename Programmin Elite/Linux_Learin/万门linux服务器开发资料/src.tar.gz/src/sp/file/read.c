#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>

#define E_EXIT(msg) \
	do { 			\
		fprintf(stderr, "[%s][%d]:%s:%s\n", __FILE__, __LINE__, msg, strerror(errno)); \
		exit(EXIT_FAILURE); \
	} while ( 0 )

typedef struct stu{
	int id;
	char name[30];
}stu_t;

int main( void ) {
	int fd = open("stu.dat", O_RDONLY);

	int num;
	printf("num:");
	scanf("%d", &num);
	lseek(fd, (num-1)*sizeof(stu_t), SEEK_SET);
	stu_t st;
	read(fd, &st, sizeof(stu_t));
	printf("id=%d, name=%s\n", st.id, st.name);

	close(fd);
}

