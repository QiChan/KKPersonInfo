#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

int main ( void ) {

	char *msg = "I love you, wanmen\n";	
	int fd = open("hehe", O_RDWR|O_CREAT, 0644);
	//close(1);
	//dup(fd);
	// dup2(fd, 1);
	close(1);
	fcntl(fd, F_DUPFD, 0);
	write(1, msg, strlen(msg));
}

