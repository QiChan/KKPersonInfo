#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>

#define E_EXIT(msg) \
	do { 			\
		fprintf(stderr, "[%s][%d]:%s:%s\n", __FILE__, __LINE__, msg, strerror(errno)); \
		exit(EXIT_FAILURE); \
	} while ( 0 )

#define BUF_SIZE 1024

//  ./a.out filename
int main( int argc, char *argv[] ) {
	if ( argc < 2 ) {
		fprintf(stderr, "Usage: %s filename\n", argv[0]); 
		exit(EXIT_FAILURE);
	}

	int fd = open(argv[1], O_RDONLY);
	if ( fd == -1 ) E_EXIT("open");

	char buf[BUF_SIZE];

	while ( 1 ) {
		memset(buf, 0x00, sizeof(buf));
		int r = read(fd, buf, BUF_SIZE);
		if ( r == 0 )
			break;
		if ( r == -1 ) E_EXIT("read");
		printf("%s", buf);
	}
}
