#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

typedef struct node{
	char *name;
	struct node *next;
}node_t;

node_t *insert(node_t *head, char *name) {
	node_t *p = malloc(sizeof(node_t));
	p->name = name;
	p->next = NULL;

	if ( head == NULL ) {
		return p;
	}

	if ( strcmp(name, head->name) < 0 ) {
		p->next = head;
		return p;
	}

	node_t *prev = head;
	node_t *cur = head->next;

	while ( cur != NULL ) {
		if ( strcmp(cur->name,p->name) > 0 ) 
			break;
		prev = cur;
		cur = cur->next;
	}

	p->next = cur;
	prev->next = p;
	return head;
}


int main( void ) {
	DIR *pd = opendir(".");
	if ( pd == NULL ) 
		perror("opendir"),exit(1);

	node_t *head = NULL;
	struct dirent *pdir = NULL;
	while ( (pdir=readdir(pd)) != NULL ) {
		if ( pdir->d_name[0] == '.' )
			continue;
		head = insert(head,pdir->d_name);
	}

	node_t *tmp = head;
	while ( tmp != NULL ) {
		printf("%s\t", tmp->name);
		tmp = tmp->next;
	}
	printf("\n");

	closedir(pd);
}

