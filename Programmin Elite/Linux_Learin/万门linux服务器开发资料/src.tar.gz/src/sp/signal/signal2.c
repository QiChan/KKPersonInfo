#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

void handler(int s) {
	printf("recv %d\n", s);
	sleep(2);
	printf("finish\n");
}

int main( void ) {
	signal(SIGUSR1, handler);
	
	pid_t pid = fork();
	if ( pid == 0 ) {
		int i;
		for (i=0; i<10; i++) {
			printf("start kill\n");
			kill(getppid(), SIGUSR1);
		}
		printf("child exit\n");
		exit(0);
	}else {
		for ( ; ; ) {
		}
	}
}

