#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <dirent.h>

enum status {PLAY, STOP, PAUSE};

typedef struct node {
	char *name;
	struct node *prev;
	struct node *next;
}node_t;

node_t *head = NULL;
node_t *cur  = NULL;
int play = STOP;
int first = 1;

void insert(char *name) {
	node_t *new_node = malloc(sizeof(node_t));
	new_node->name = malloc(strlen(name)+1);
	strcpy(new_node->name, name);
	
	if ( head == NULL ) {
		head = new_node;
		new_node->next = new_node;
		new_node->prev = new_node;
		cur = head;
	} else {
		new_node->next = head;
		new_node->prev = head->prev;
		head->prev->next = new_node;
		head->prev = new_node;
	}
}

void music_list( void ) {
	DIR *pdir = opendir("./music");
	if ( pdir == NULL )
		exit(0);

	struct dirent *pd = NULL;
	while ( (pd=readdir(pdir)) != NULL ) {
		if ( pd->d_name[0] == '.' )
			continue;
		char buf[256];
		sprintf(buf, "./music/%s", pd->d_name);
		insert(buf);
	}
}

int menu( void ) {
	printf("--------------mp3 player-------\n");
	printf(" 1 继续/暂停\n");
	printf(" 2 下一首\n");
	printf(" 3 上一首\n");
	printf(" 4 结束\n");
	printf(" 5 退出\n");

	int choose;
	printf("请选择:");
	scanf("%d", &choose);
	return choose;
}

void play_puse() {
	char buf[256] = {};
	if ( first == 1 ) {
		sprintf(buf, "madplay -o wav:- %s | aplay -D hw:0,0 &", cur->name);
		system(buf);
		play = PLAY;
		first = 0;
	} else {
		if ( play == PLAY ) {
			system("killall -SIGSTOP aplay");
			play = PAUSE;
		} else {
			system("killall -SIGCONT aplay");
			play = PLAY;
		}
	}
}

void stop() {
	first = 1;
	system("killall -SIGKILL aplay");
}

void next() {
	stop();
	cur = cur->next;
	play_puse();
}

void prev() {
	stop();
	cur = cur->prev;
	play_puse();
}

void quit() {
	stop();
	exit(0);
}

void show( void ) {
	node_t *cur = head;
	if ( cur == NULL )
		return;

	do {
		printf("%s\n", cur->name);
		cur = cur->next;
	} while ( cur!=head);
}

int main( void ) {

	music_list();
	show();
	
	do {
		int choose = menu();
		switch ( choose ) {
		case 1:
		play_puse();
		break;
		case 2:
		next();
		break;
		case 3:
		prev();
		break;
		case 4:
		stop();
		break;
		case 5:
		quit();
		break;
		defult:
		printf("按键错误\n");
		break;
		}
	} while ( 1 );
}
