#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

void handler(int s) {
	printf("recv %d\n", s);
	sleep(5);
	printf("handler finish\n");
}

int main( void ) {
	printf("%d\n", getpid());
	signal(SIGINT, handler);
	sigset_t set;
	sigemptyset(&set);
	sigaddset(&set, SIGQUIT);
	for ( ; ; ) {
		printf("hehe\n");
		sigsuspend(&set);
		printf("suspend return\n");
	}

	
}

