#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

void print(sigset_t *set) {
	int i;
	for (i=1; i<=64; i++) {
		if ( sigismember(set, i) )
			printf("%c", '1');
		else
			printf("%c", '0');
	}
	printf("\n");
}

void handler(int s) {
	if ( s == SIGINT ) {
		printf("recv %d\n", s);
	}else if ( s == SIGQUIT ) {
		sigset_t set;
		sigemptyset(&set);
		sigaddset(&set, SIGINT);
		sigprocmask(SIG_UNBLOCK, &set, NULL);
	}
}

int main( void ) {
	sigset_t set;
	sigset_t pset;

	sigemptyset(&set);
	signal(SIGQUIT, handler);
	signal(SIGINT, handler);

	sigaddset(&set, SIGINT);
	sigprocmask(SIG_BLOCK, &set, NULL);

	for ( ; ; ) {
		sigemptyset(&pset);
		sigpending(&pset);
		print(&pset);
		sleep(1);
	}
}

