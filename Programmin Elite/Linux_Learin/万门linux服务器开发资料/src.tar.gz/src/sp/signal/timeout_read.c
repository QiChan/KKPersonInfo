#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>

void handler(int s) {
	printf("time out\n");
	exit(0);
}

int main( void ) {
	char buf[1024] = {};

	alarm(5);
	signal(SIGALRM, handler);

	int r = read(0, buf, 1024);
	if ( r <= 0 )
		perror("read");
	alarm(0);
	printf("buf=%s\n", buf);

	for ( ; ; )
		;
}

