#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>

void handler(int s) {
	while ( waitpid(-1, NULL, WNOHANG) > 0 )
		;
}

int main( void ) {
	int pid;
	int i;
	int N = 5;

	// signal(SIGCHLD, handler);
	signal(SIGCHLD, SIG_IGN);

	for ( i=0; i<N; i++ ) {
		pid = fork();
		if ( pid == 0 )
			break;
	}

	for ( ; ; ) {
		printf(". pid=%d, ppid=%d\n", getpid(), getppid());
		sleep(1);
	}
}

