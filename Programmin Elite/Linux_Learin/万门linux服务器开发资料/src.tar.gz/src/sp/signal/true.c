#include <stdio.h>
#include <stdlib.h>

int main( void ) {
	while ( 1 ) {
		printf(".");
		fflush(stdout);
		sleep(1);
	}
}

