#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
	if ( argc < 3 ) {
		fprintf(stderr, "usage:%s pid, signo\n", argv[0]);
		exit(1);
	}

	int pid = atoi(argv[1]);
	int sig = atoi(argv[2]);

	kill(pid, sig);
}
