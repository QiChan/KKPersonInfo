#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>
#include <signal.h>

void show(int y, int x) {
	printf("\033[%d;%dH  \n", y-1, x);
	printf("\033[%d;%dH[]\n", y, x);
}

int y = 0;
int x = 4;
void handler(int s) {
	show(++y, x);
}

int main( void ) {
	signal(SIGALRM, handler);

	struct itimerval it;
	it.it_value.tv_sec  = 3;
	it.it_value.tv_usec = 0;
	it.it_interval.tv_sec  = 1;
	it.it_interval.tv_usec = 0;
	setitimer(ITIMER_REAL, &it, NULL);

	for ( ; ; ) {
	}
}

