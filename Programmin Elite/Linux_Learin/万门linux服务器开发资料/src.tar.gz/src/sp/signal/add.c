#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

int v = 0;
int x = 0;

void handler(int s) {
	printf("时间到了，你还没做完\n");
	printf("v=%d, x=%d\n", v, x);
	exit(0);
}

int main( void ) {
	alarm(20);

	int a, b;
	int ret;
	int i;

	signal(SIGALRM, handler);

	srand(getpid());

	for (i=0; i<10; i++) {
		a = rand() % 100 + 1;
		b = rand() % 100 + 1;
		printf("%d+%d=", a, b);
		scanf("%d", &ret);
		if ( a+b == ret ) {
			v++;
		} else {
			x++;
		}
	}
	printf("v=%d, x=%d\n", v, x);
}

