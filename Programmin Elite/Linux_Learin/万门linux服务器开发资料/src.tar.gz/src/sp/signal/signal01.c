#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>

void handler(int s) {
	printf("recv %d\n", s);
}

int main( void ) {
	__sighandler_t old = NULL;
	//if ( (old=signal(SIGINT, SIG_IGN)) == SIG_ERR ) {
	if ( (old=signal(SIGINT, handler)) == SIG_ERR ) {
		perror("signal");
	}

	while ( 1 ) {
		// printf(".");
		// fflush(stdout);
		// sleep(1);
		int c = getchar();
		if ( c == 'a')
			break;
	}

	signal(SIGINT, old);

	for ( ; ; ) {
		printf(".");
		fflush(stdout);
		sleep(1);
	}
}

