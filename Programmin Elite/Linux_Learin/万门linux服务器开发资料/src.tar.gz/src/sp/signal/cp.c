#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

void handler(int s) {
	printf("处理信号开始\n");
	sleep(2);
	printf("信号处理结束\n");
}

int main( void ) {
	sigset_t set;
	signal(SIGINT, handler);

	sigemptyset(&set);
	sigaddset(&set, SIGINT);
	sigprocmask(SIG_BLOCK, &set, NULL);

	int i;
	srand(getpid());

	for ( i=0; i<5; ++i ) {
		printf("开始拷贝%d段视频\n", i+1);
		sleep(5);
		printf("%d段视频拷贝结束\n", i+1);
		sigset_t pset;
		sigemptyset(&pset);
		sigpending(&pset);
		if ( sigismember(&pset, SIGINT) ) {
			sigset_t nset;
			sigemptyset(&nset);
			sigsuspend(&nset);
		} 
	}

	sigprocmask(SIG_UNBLOCK, &set, NULL);
}

