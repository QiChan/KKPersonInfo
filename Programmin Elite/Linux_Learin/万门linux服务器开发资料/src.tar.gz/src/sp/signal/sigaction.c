#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

void handler(int s) {
	printf("rec %d\n", s);
}

__sighandler_t mysignal( int signum, __sighandler_t handler ) {
	struct sigaction act;
	struct sigaction old;

	act.sa_handler = handler;
	sigemptyset(&act.sa_mask);
	act.sa_flags = 0;

	if ( sigaction(signum, &act, &old) == -1 )
			return SIG_ERR;

	return old.sa_handler;
}

int main( void ) {
	struct sigaction act;
	act.sa_handler = handler;
	sigemptyset(&act.sa_mask);
	act.sa_flags = 0;
	sigaction(SIGINT, &act, NULL); 

	for ( ; ; ) {
		printf("hehe\n");
		pause();
	}
}

