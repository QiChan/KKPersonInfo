#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

typedef struct node {
	int a;
	int b;
	int c;
}node_t;

node_t first = {0,0,0};
node_t second = {1, 1, 1};

void handler(int s) {
	alarm(1);
	printf("a=%d, b=%d, c=%d\n", first.a, first.b, first.c);
}

int main( void ) {
	
	signal(SIGALRM, handler);
	alarm(1);
	
	for ( ; ; ) {
		node_t t = first;
		first = second;
		second = t;
	}
}

