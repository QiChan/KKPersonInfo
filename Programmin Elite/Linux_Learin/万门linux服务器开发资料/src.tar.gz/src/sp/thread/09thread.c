#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

static __thread int g_data;

void *r1( void *arg ) {
	int i = *(int*)arg;	
	g_data = i;

	sleep(1);
	printf("g_data = %d\n", g_data);
}

int main( void ) {
	pthread_t t1, t2;
	int *p = malloc(sizeof(int));
	*p = 1;
	pthread_create(&t1, NULL, r1, (void*)p);
	int *p2 = malloc(sizeof(int));
	*p2 = 2;
	pthread_create(&t2, NULL, r1, (void*)p2);

	pthread_join(t1, NULL);
	pthread_join(t2, NULL);
}

