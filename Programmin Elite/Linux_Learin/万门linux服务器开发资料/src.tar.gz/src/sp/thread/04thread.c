#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

pthread_rwlock_t rwlock;
int g_data = 0;

void *rd_func(void *arg) {
	int i = *(int*)arg;
	free(arg);

	while ( 1 ) {
		pthread_rwlock_rdlock(&rwlock);
		printf("读线程 %d : g_data=%d\n", i, g_data);
		pthread_rwlock_unlock(&rwlock);
		sleep(rand()%5);
	}	
}

void *wr_func(void *arg) {
	
	while ( 1 ) {
		pthread_rwlock_wrlock(&rwlock);
		int t = g_data;		
		printf("====写线程 %d : t=%d, g_data=%d\n", t, g_data);
		g_data ++;
		pthread_rwlock_unlock(&rwlock);
		sleep(rand()%5);
	}
}

int main( void ) {
	pthread_t tid[5];
	int i;

	srand(getpid());
	pthread_rwlock_init(&rwlock, NULL);

	for (i=0; i<3; i++) {
		int *p = (void*)malloc(sizeof(int));
		*p = i;
		pthread_create(&tid[i], NULL, rd_func, (void*)p);
	}

	for (i=0; i<2; i++) {
		int *p = (void*)malloc(sizeof(int));
		*p = i;
		pthread_create(&tid[3+i], NULL, wr_func, (void*)p);
	}

	for (i=0; i<5; i++)
		pthread_join(tid[i], NULL);

	pthread_rwlock_destroy(&rwlock);
}

