#include <stdio.h>
#include <stdlib.h>

#include "thread_pool.h"

void run(void *arg) {
		int i = *(int*)arg;
		printf("%d task run on %d thread\n", i, pthread_self());
		sleep(rand()%5);
		printf("%d task finish     %d\n", i, pthread_self());
}

int main( void ) {
	thread_pool_t pool;
	
	srand(getpid());
	thread_pool_init(&pool, 3);

	int i;
	for (i=0; i<5; i++) {
		int *p = malloc(sizeof(int));
		*p = i+1;
		thread_pool_add(&pool, run, p);
	}

	thread_pool_destroy(&pool);
}

