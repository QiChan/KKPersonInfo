#include <stdio.h>
#include <stdlib.h>

#include "thread_pool.h"

void *routine( void *arg ) {
	thread_pool_t *pool = (thread_pool_t*)arg;

	while ( 1 ) {
		pthread_mutex_lock(&pool->mutex);

		pool->idle++;
		while ( pool->queue->first == NULL && pool->quit == 0 ) {
			printf("%d thread wait\n", pthread_self());
			pthread_cond_wait(&pool->cond, &pool->mutex);
			printf("%d weak up\n", pthread_self());
		}
		
		pool->idle--;

		if ( pool->queue->first != NULL ) {
			thread_task_t *tmp = pool->queue->first;
			pool->queue->first = tmp->next;

			pthread_mutex_unlock(&pool->mutex);
			tmp->handler(tmp->arg);
			free(tmp);
			pthread_mutex_lock(&pool->mutex);
		}

		if ( pool->quit == 1 && pool->queue->first != NULL ) {
			pthread_mutex_unlock(&pool->mutex);
			pool->cntr--;
			printf("%d thread exit\n", pthread_self());
			if ( pool->cntr == 0 ) {
				pthread_cond_signal(&pool->cond);
			}			
			break;
		}

		pthread_mutex_unlock(&pool->mutex);
	}
}

void thread_pool_init(thread_pool_t *pool, int num)
{
	pool->queue = malloc(sizeof(thread_queue_t));
	pool->queue->first = NULL;
	pool->queue->last  = NULL;

	pool->threads = num;
	pool->cntr    = 0;
	pool->idle    = 0;
	pool->quit    = 0;
	pthread_cond_init(&pool->cond, NULL);
	pthread_mutex_init(&pool->mutex, NULL);

	int i;
	for (i=0; i<num; i++ ) {
		pthread_t tid;
		pthread_create(&tid, NULL, routine, pool);
		pool->cntr ++;
	}
}

void thread_pool_add(thread_pool_t *pool, void (*routine)(void *), void *arg)
{
	thread_task_t *new_node = malloc(sizeof(thread_task_t));
	new_node->handler = routine;
	new_node->arg     = arg;
	new_node->next    = NULL;

	pthread_mutex_lock(&pool->mutex);

	if ( pool->queue->first == NULL ) {
		pool->queue->first = new_node;
	} else {
		pool->queue->last->next = new_node;
	}
	pool->queue->last = new_node;

	pthread_cond_signal(&pool->cond);
	
	pthread_mutex_unlock(&pool->mutex);
}

void thread_pool_destroy(thread_pool_t *pool)
{
	pool->quit = 1;

	pthread_mutex_lock(&pool->mutex);
	if ( pool->cntr > 0 ) {
		pthread_cond_broadcast(&pool->cond);
		while ( pool->idle > 0 ) {
			pthread_cond_wait(&pool->cond, &pool->mutex);
		}
	}
	pthread_mutex_unlock(&pool->mutex);
	
	pthread_cond_destroy(&pool->cond);
	pthread_mutex_destroy(&pool->mutex);
}

