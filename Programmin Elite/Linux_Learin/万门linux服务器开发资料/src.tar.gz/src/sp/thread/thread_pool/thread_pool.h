#ifndef __THREAD_POOL_
#define __THREAD_POOL_

#include <pthread.h>

typedef struct node {
	void (*handler)(void *arg);
	void *arg;
	struct node *next;
}thread_task_t;

typedef struct queue_ {
	thread_task_t *first;
	thread_task_t *last;
}thread_queue_t;

typedef struct thread_pool {
	thread_queue_t *queue; // 任务队列
	pthread_mutex_t mutex;
	pthread_cond_t cond;

	int threads;  // 线程池中总有的线程个数
	int cntr;     // 当前线程池中的线程个数
	int idle;     // 空闲线程个数
	int quit;     // 线程退出标记
}thread_pool_t;

void thread_pool_init(thread_pool_t *pool, int num);
void thread_pool_add(thread_pool_t *pool, void (*routine)(void *), void *arg);
void thread_pool_destroy(thread_pool_t *pool);

#endif //__THREAD_POOL_

