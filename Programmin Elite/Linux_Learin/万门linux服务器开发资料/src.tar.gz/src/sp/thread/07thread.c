#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

sem_t full;
sem_t empty;

int cap[4];

void *p_func( void * arg ) {
	int i = 0, k;
	int cnt = 1;
	while ( 1 ) {
		sem_wait(&full);
		cap[i] = cnt++;
		for (k=0; k<4; k++) {
			printf("[%d]=%d", k, cap[k]);
			if ( k == i )
				printf("<=== %d\n", i);
			else
				printf("\n");
		}
		i = (i + 1) % 4;
		sleep(rand()%5);
		sem_post(&empty);
	}
}

void *c_func( void * arg ) {
	int i = 0, k;
	while ( 1 ) {
		sem_wait(&empty);

		printf("cap[%d] = %d\n", i, cap[i]); 
		cap[i] = 0;
		for (k=0; k<4; k++) {
				printf("[%d]=%d", k, cap[k]);
			if ( k == i )
				printf("===> %d\n", i);
			else
				printf("\n");
		}
		i = (i+1)%4;
		sem_post(&full);
		sleep(rand()%3);
	}
}

int main( void ) {
	sem_init(&full, 0, 4);
	sem_init(&empty, 0, 0);

	pthread_t t1, t2;	

	srand(time(NULL));
	pthread_create(&t1, NULL, p_func, NULL);
	pthread_create(&t2, NULL, c_func, NULL);

	pthread_join(t1, NULL);
	pthread_join(t2, NULL);

	sem_destroy(&full);
	sem_destroy(&empty);
}


