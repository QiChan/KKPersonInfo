#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define PRO_CNT 4
#define CUR_CNT 4

int g_data = 0;
pthread_cond_t cond;
pthread_mutex_t mutex;

void *proc( void * arg ) {
	int i = *(int*)arg;
	free(arg);

	while ( 1 ) {
		pthread_mutex_lock(&mutex);
		printf("%d生产者线程开始生产产品====%d\n", i, g_data+1);
		sleep(rand()%3);
		g_data ++;
		printf("%d生产者线程生产完毕====%d\n", i, g_data);
		pthread_mutex_unlock(&mutex);
		sleep(rand()%2);
	}
}

void *cus( void * arg ) {
	int i = *(int*)arg;
	free(arg);
	while ( 1 ) {
		pthread_mutex_lock(&mutex);
		while ( g_data <= 0 ) {
			printf("-----%d消费者线程在等待消费\n", i);
			pthread_cond_wait(&cond, &mutex);
		}
		printf("%d消费者线程开始消费 ===> %d\n", i, g_data);
		//sleep(rand()%2);
		g_data --;
		printf("%d消费者线程消费结束---===> %d\n", i, g_data);
		pthread_mutex_unlock(&mutex);
		sleep(rand()%2);
	}
}

int main( void ) {
	pthread_t tid[PRO_CNT+CUR_CNT];
	int i;
	pthread_cond_init(&cond, NULL);
	pthread_mutex_init(&mutex, NULL);
	srand(getpid());

	for (i=0; i<PRO_CNT; i++) {
		int *p = malloc(sizeof(int));
		*p = i+1;
		pthread_create(&tid[i], NULL, proc, (void*)p);
	}
	
	for (i=0; i<CUR_CNT; i++) {
		int *p = malloc(sizeof(int));
		*p = i+1;
		pthread_create(&tid[PRO_CNT+i], NULL, cus, (void*)p);
	}

	for (i=0; i<CUR_CNT+PRO_CNT; i++) {
		pthread_join(tid[i], NULL);
	}

	pthread_mutex_destroy(&mutex);
	pthread_cond_destroy(&cond);
}

