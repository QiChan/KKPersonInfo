#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>

void *thread_run1( void *arg ) {
	char *info = (char*)arg;
	while ( 1 ) {
		// printf("线程1跑起来了, %s , %lu\n", info, pthread_self());
		// sleep(1);
	}
	pthread_exit(NULL); //  自杀  exit

	return (void*)"我小消亡了";
}

int main( void ) {
	pthread_t tid;
	pthread_create(&tid, NULL, thread_run1, (void*)"我的第一个线程"); // fork

	sleep(3);
	int r = pthread_cancel(tid);     //kill
	if ( r != 0 ) {
		printf("pthread cancel : %s\n", strerror(r));
	}
	pthread_detach(tid); // 设置成分离状态
	while ( 1 ) {
		printf("main 函数执行%lu \n", tid);
		sleep(1);
	}


	char *ret;
	// pthread_join(tid, (void**)&ret); // wait/waitpid

	printf("main 函数执行到结束位置了 %lu , %s\n", tid, ret);
	// sleep(1);
}

