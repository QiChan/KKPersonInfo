#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

pthread_cond_t cond;
pthread_mutex_t mutex;

void *wait(void *arg) {
		while ( 1 ) {
			pthread_cond_wait(&cond, &mutex);
			printf("wait return\n");
		}
}

void *post(void *arg) {
	while ( 1 ) {
		sleep(1);
		pthread_cond_signal(&cond);
	}
}

int main( void ) {
	pthread_cond_init(&cond, NULL);
	pthread_mutex_init(&mutex, NULL);

	pthread_t t1, t2;

	pthread_create(&t1, NULL, wait, NULL);
	pthread_create(&t2, NULL, post, NULL);

	pthread_join(t1, NULL);
	pthread_join(t2, NULL);

	pthread_mutex_destroy(&mutex);
	pthread_cond_destroy(&cond);
}

