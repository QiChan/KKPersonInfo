#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

pthread_mutex_t mutex;

void route(void *arg) {
		printf("pthread_cleanpu_push call back\n");
		sleep(2);
		pthread_mutex_unlock(&mutex);
}

void *alph(void *arg) {
	int i = 0;

	while ( 1 ) {
		pthread_cleanup_push(route, NULL);
		pthread_mutex_lock(&mutex);
		printf("%c\n", 'a'+(i%26));
		pthread_mutex_unlock(&mutex);
		pthread_cleanup_pop(0);
		i++;
	}
}

void *num(void *arg) {
	int i = 0;
	while ( 1 ) {
		pthread_mutex_lock(&mutex);
		printf("%d\n", i);
		pthread_mutex_unlock(&mutex);
		i++;
	}
}

int main( void ) {
	pthread_mutex_init(&mutex, NULL);
	pthread_t t1, t2;

	pthread_create(&t1, NULL, alph, NULL);
	pthread_create(&t2, NULL, num, NULL);

	sleep(3);
	pthread_cancel(t1);

	pthread_join(t1, NULL);
	pthread_join(t2, NULL);

	pthread_mutex_destroy(&mutex);
}

