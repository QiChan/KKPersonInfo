#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

pthread_mutex_t mutex;

int g_a = 0;
int g_b = 0;

void *route(void *arg) {

	while ( 1 ) {
		pthread_mutex_lock(&mutex);
		g_a++;
		g_b++;
		if ( g_a != g_b ) {
			printf("a=%d, b=%d\n", g_a, g_b);
			g_a = 0;
			g_b = 0;
		}
		pthread_mutex_unlock(&mutex);
	}
}

int main( void ) {
	pthread_t t1, t2;

	pthread_mutex_init(&mutex, NULL);
	pthread_create(&t1, NULL, route, NULL);
	pthread_create(&t2, NULL, route, NULL);

	pthread_join(t1, NULL);
	pthread_join(t2, NULL);
	pthread_mutex_destroy(&mutex);
}

