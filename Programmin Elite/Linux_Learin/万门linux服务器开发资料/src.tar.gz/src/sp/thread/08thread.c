#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

pthread_key_t key;

void delete(void *arg) {
	printf("delete\n");
	free(arg);
}

void *r1( void *arg ) {
	int *p = malloc(sizeof(int));
	*p = *(int*)arg;
	pthread_setspecific(key, p);	
	sleep(1);
	int r = *(int*)pthread_getspecific(key);
	printf("r = %d\n", r);
}

int main( void ) {
	pthread_t t1, t2;

	pthread_key_create(&key, delete);

	int *p = malloc(sizeof(int));
	*p = 1;
	pthread_create(&t1, NULL, r1, (void*)p);
	int *p2 = malloc(sizeof(int));
	*p2 = 2;
	pthread_create(&t2, NULL, r1, (void*)p2);

	pthread_join(t1, NULL);
	pthread_join(t2, NULL);
	pthread_key_delete(key);
}

