#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main( void ) {
	printf("in main\n");

	execlp("ls", "ls", "-l", NULL);
	
	printf("out main\n");
}

