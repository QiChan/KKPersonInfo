#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main( void ) {
	pid_t pid = fork();
	
	printf("pid = %d\n", pid);

	if ( pid == 0 ) {
		sleep(3);
		for ( ; ; )
			;
		exit(2);
	} else {
		int status;
		printf("wait return %d\n", waitpid(-1, &status, WNOHANG));
		if ( WIFEXITED(status) ) {
			printf("exit code %d\n", WEXITSTATUS(status));
		}
		if ( WIFSIGNALED(status) ) {
			printf("killed by signal %d\n", WTERMSIG(status));
		}
		
		for ( ; ; ) 
			;
	}
}

