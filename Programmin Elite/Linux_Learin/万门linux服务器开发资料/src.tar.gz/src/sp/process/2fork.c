#include <stdio.h>
#include <unistd.h>

int main( void ) {
	int i, n;
	printf("n:");
	scanf("%d", &n);

	for (i=1; i<=n; i++) {
		if ( fork() == 0 )
			break;
	}

	printf("i=%d, pid=%d, ppid=%d\n", i, getpid(), getppid());
	sleep(1);
}

