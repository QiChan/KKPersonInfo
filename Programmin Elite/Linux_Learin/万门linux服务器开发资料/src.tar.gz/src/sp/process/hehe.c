#include <stdio.h>
#include <unistd.h>

int main( void ) {
	printf("hehe\n");
	write(3, "wan", 3);
}

