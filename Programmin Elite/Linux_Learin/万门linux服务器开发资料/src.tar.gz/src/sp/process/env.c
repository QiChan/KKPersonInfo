#include <stdio.h>
#include <stdlib.h>

extern char ** environ;

int main( int argc, char *argv[], char *envp[] ) {

/*
	putenv("NAME=wanmen");
	char *val = getenv("NAME");
	if ( val == NULL )
		printf("NULL\n");
	else
		printf("%s\n", val);
*/
	int i;
	for (i=0; environ[i]!=NULL; i++)
		printf("%d : %s\n", i, environ[i]);
}


