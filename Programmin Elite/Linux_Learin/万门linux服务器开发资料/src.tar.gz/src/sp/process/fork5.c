#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void f1( void ) {
	printf("f1\n");
}

void f2( void ) {
	printf("f2\n");
}

typedef struct node {
	void (*pf)(void);
	struct node *next;
}node_t;

node_t *head = NULL;

int myatexit( void (*pf)(void) ) {
	node_t *p = malloc(sizeof(node_t));
	p->pf = pf;
	p->next = NULL;
	if ( head == NULL ) {
		head = p;
	} else {
		p->next = head;
		head = p;
	}
}


void myexit(int s) {
	fflush(stdout);
	while ( head != NULL ) {
		head->pf();
		head = head->next;
	}
	_exit(s);
}

int main( void ) {
	myatexit(f1);
	myatexit(f2);
	int i;
	for ( i=0; i<5; i++) {
		printf("#");
		//sleep(1);
	}
	//sleep(1);
	myexit(0);
}

