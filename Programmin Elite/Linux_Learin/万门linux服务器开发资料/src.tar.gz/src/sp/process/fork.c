#include <stdio.h>
#include <unistd.h>

int main( void ) {
	printf("before fork, current process pid = %d\n", getpid());
	pid_t pid;

	pid = fork();
	if ( pid == 0 ) {
		printf("child process pid=%d, my parent pid=%d\n", getpid(), getppid());
		for ( ; ; )
			printf("-------------child\n");
	} else {
		printf("parent process pid=%d, my child pid = %d\n", getpid(), pid);
		for ( ; ; )
			printf("parent-------------\n");
	}
	/*switch ( pid ) {
	case -1:
		perror("fork");
	break;
	case 0:
		printf("child process pid=%d, my parent pid=%d\n", getpid(), getppid());
	break;
	default:
		printf("parent process pid=%d, my child pid = %d\n", getpid(), pid);
	break;
	} */

	printf("finish\n");
}

