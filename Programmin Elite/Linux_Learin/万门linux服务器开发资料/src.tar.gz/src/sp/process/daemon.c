#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

int main( void ) {
	pid_t pid = fork();

	if ( pid > 0 ) 
		exit(0);

	setsid();

	chdir("/");
	close(0);
	close(1);
	close(2);
	int fd = open("daemon.log", O_RDWR|O_APPEND);
	for ( ; ; ) {
		write(fd, "wanmen", 6);
		sleep(1);
	}
	close(fd);

}

