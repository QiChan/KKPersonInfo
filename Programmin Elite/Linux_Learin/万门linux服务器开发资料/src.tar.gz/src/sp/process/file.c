#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

int main( void ) {
	int fd = open("my.txt", O_RDWR);
	pid_t pid = fork();

	if ( pid == 0 ) {
		write(fd, "abc", 3);
		close(fd);
	} else { 
		write(fd, "defgijk", 7);
		close(fd);
	}
}

