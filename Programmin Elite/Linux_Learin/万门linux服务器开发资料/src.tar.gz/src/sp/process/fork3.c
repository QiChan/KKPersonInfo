#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main( void ) {
	pid_t pid = fork();

	if ( pid == 0 ) {
		printf("child heheh\n");
		sleep(3);
		printf("child over\n");
	} else { 
		printf("parent begin\n");
		printf("heheheheheh\n");
	}
}

