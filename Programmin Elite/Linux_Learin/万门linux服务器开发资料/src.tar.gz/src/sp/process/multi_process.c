#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sched.h>

void	worker_process_init(int i) {
	printf("child init\n");

	cpu_set_t cpu;

	CPU_ZERO(&cpu);
	CPU_SET(i%CPU_SETSIZE, &cpu);

	sched_setaffinity(0, sizeof(cpu_set_t), &cpu);
}

void worker_process_cycle(int i) {

	worker_process_init(i);

	for ( ; ; ) {
		printf("worker process %d \n", i);
		sleep(1);
	}
}

void spwan_worker(int i) {
	pid_t pid = fork();
	switch( pid ) {
	case -1:
		printf("create child errr:%s\n", strerror(errno));
	break;
	case 0:
		worker_process_cycle(i);
	break;
	default:
	break;
	}
}

void start_worker_process(int wp) {
	int i;
	
	for (i=0; i<wp; i++) {
		spwan_worker(i);
	}
}

void master_process_cycle() {

	int wp = 2;
	start_worker_process(wp);

	for ( ; ; ) {
		printf("master进程监控子进程的工作状态\n");
		sleep(1);
	}
}

int main( void ) {
	master_process_cycle();
}

