#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <ctype.h>

char buf[512];	
char *argv[10];
int  argc = 0;

#define OUT 0
#define IN  1

void doaction( void ) {
	pid_t pid = fork();
	
	switch( pid ) {
	case -1:
	break;
	case 0:
		execvp(argv[0], argv);
		printf("command not found\n");
		exit(0);
	break;
	default:
		wait(NULL);
	break;
	}
}

void parse( void ) {
	int status = OUT;
	int i;

	argc = 0;
	for (i=0; buf[i]!='\0'; i++) {
		if ( status==OUT && !isspace(buf[i]) ) {
			argv[argc++] = buf+i;
			status = IN;
		} else if ( status==IN && isspace(buf[i]) ) {
			buf[i] = '\0';
			status = OUT;
		}
	}
	argv[argc] = NULL;
}

int main( void ) {
	while ( 1 ) {
		printf("wanmen > ");
		memset(buf, 0x00, sizeof(buf));
		scanf("%[^\n]%*c", buf);
		if ( strncmp(buf, "exit", 4) == 0 )
			return 0;
		parse();
		doaction();
	}

}

