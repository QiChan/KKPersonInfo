#include <stdio.h>
#include <string.h>

int main( int argc, char *argv[] ) {
	int i;
	printf("argc=%d\n", argc);
	//for (i=0; i<argc; i++)
	// for (i=0; argv[i]; i++)
	//	printf("%d:%s\n", i, argv[i]);
	// strcpy(argv[0], "wan men");
	
	for (i=0; i<5; i++)
		if ( argv[i] != NULL ) 
			printf("%d:%s\n", i, argv[i]);

	// for ( ; ; )
		//pause();
}

