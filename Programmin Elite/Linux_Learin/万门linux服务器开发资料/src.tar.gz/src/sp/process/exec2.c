#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main( void ) {
	pid_t pid =fork();

	if ( pid == 0 ) {
		char *argv[] = {
			"ls",
			"-l",
			NULL
		};
		execvp("ls", argv);
	} else {
		wait(NULL);
		printf("fffff\n");
	}
}

