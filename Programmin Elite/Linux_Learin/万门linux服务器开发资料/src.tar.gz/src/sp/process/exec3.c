#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

int main( void ) {
	int fd = open("abc", O_RDWR/*|O_CLOEXEC*/);
	fcntl(fd, F_SETFD, FD_CLOEXEC);
	execlp("./hehe", "hehe", NULL);
	perror("execlp");
}

