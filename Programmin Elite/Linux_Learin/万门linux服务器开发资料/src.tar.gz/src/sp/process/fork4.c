#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int g_data = 20;

int main( void ) {
	pid_t pid = vfork();

	if ( pid == 0 ) {
		g_data = 10;
		printf("child g_data = %d\n", g_data);
	} else {
		sleep(1);
		printf("parent g_data = %d\n", g_data);
	}
}

