#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

int main( void ) {

	int lfd = socket(AF_INET, SOCK_STREAM, 0);
	int op = 1;
	setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &op, sizeof(op));
	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port   = htons(9090);
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	int r = bind(lfd, (struct sockaddr*)&addr, sizeof(addr));
	if ( r == -1 ) perror("bind"),exit(1);
	r = listen(lfd, 10);
	if ( r == -1 ) perror("listen"),exit(1);

	int client[FD_SETSIZE];
	int i;
	for (i=0; i<FD_SETSIZE; i++)
		client[i] = -1;
	int maxfd = lfd;
	int maxi  = 0;
	
	fd_set rset;
	fd_set allset;

	FD_ZERO(&allset);
	FD_ZERO(&rset);
	FD_SET(lfd, &allset);
	maxfd = lfd;
	while ( 1 ) {
		rset = allset;
		int nready = select(maxfd+1, &rset, NULL, NULL, NULL);
		if ( nready == -1 || nready == 0 )
			continue;

		if ( FD_ISSET(lfd, &rset) ) {
			int nfd = accept(lfd, NULL, NULL);
			if ( nfd == -1 ) continue;
			for (i=0; i<FD_SETSIZE; i++) {
				if ( client[i] == -1 ) {
					client[i] = nfd;
					if ( maxi < i )
						maxi = i;
					break;
				}
			}
			if ( i == FD_SETSIZE ) {
				printf("太多的客户端\n");
				exit(0);
			}
			FD_SET(nfd, &allset);
			if ( nfd > maxfd )
				maxfd = nfd;
			if ( --nready <= 0 )
				continue;
		}

		for (i=0; i<=maxi; i++) {
			if ( FD_ISSET(client[i], &rset) ) {
				char buf[1024] = {};
				int r = read(client[i], buf, 1024);
				if ( r == 0 ) {
					FD_CLR(client[i], &allset);
					client[i] = -1;
					continue;
				}
				if ( r < 0 )
					perror("read"),exit(0);
				printf("recv = %s\n", buf);
				write(client[i], buf, strlen(buf));
			}
		}

	}
}

