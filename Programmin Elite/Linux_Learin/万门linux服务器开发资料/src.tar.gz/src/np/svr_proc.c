#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <errno.h>
#include <signal.h>

void handler(int s) {
	waitpid(-1, NULL, WNOHANG);
}

void do_action(int newfd, struct sockaddr_in *addr) {
	while ( 1 ) {
		char buf[1024] = {};
		int r = read(newfd, buf, 1024);
		if ( r <= 0 ) {
			printf("%s client close\n", inet_ntoa(addr->sin_addr));
			break;
		}
		printf("%s : %s\n", inet_ntoa(addr->sin_addr), buf);
		write(newfd, buf, r);
	}
}

int main( void ) {
	int lfd = socket(AF_INET, SOCK_STREAM, 0);
	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port = htons(9090);
	addr.sin_addr.s_addr = htonl(INADDR_ANY);

	int op = 1;
	setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &op, sizeof(op));

	int r = bind(lfd, (struct sockaddr*)&addr, sizeof(addr));
	if ( r == -1 ) perror("bind"),exit(1);

	struct sigaction act;
	act.sa_handler = handler;
	sigemptyset(&act.sa_mask);
	act.sa_flags = 0;
	sigaction(SIGCHLD, &act, NULL);
	
	r = listen(lfd, SOMAXCONN);
	if ( r == -1 ) perror("listen"),exit(1);

	while ( 1 ) {
		struct sockaddr_in peer_addr;
		socklen_t len = sizeof(peer_addr);
		int newfd = accept(lfd, (struct sockaddr*)&peer_addr, &len);
		if ( newfd == -1 ) continue;
		printf("%s:%u client connection\n", inet_ntoa(peer_addr.sin_addr), ntohs(peer_addr.sin_port));
		
		pid_t pid = fork();
		if ( pid == 0 ) {
			close(lfd);
			do_action(newfd, &peer_addr);
			close(newfd);
			exit(0);
		} else {
			close(newfd);
		}
	}
}

