#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <pthread.h>

int main( void ) {
	int fd = socket(AF_INET, SOCK_STREAM, 0);

	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port = htons(9090);
	inet_aton("127.0.0.1", &addr.sin_addr);
	int r = connect(fd, (struct sockaddr*)&addr, sizeof(addr));
	if ( r == -1 ) printf("connect err:%s\n", strerror(errno));

	fd_set rset;

	FD_ZERO(&rset);
	int stdin_fd = fileno(stdin);
	int max_fd = stdin_fd > fd ? stdin_fd : fd;

	while ( 1 ) {
		FD_SET(stdin_fd, &rset);
		FD_SET(fd, &rset);
		int nready = select(max_fd+1, &rset, NULL, NULL, NULL);
		if ( FD_ISSET(stdin_fd, &rset) ) {
			char buf[1204] = {};
			if ( fgets(buf, 1024, stdin) != NULL ) {
				write(fd, buf, strlen(buf));
			} else 
				break;
		}	
		if ( FD_ISSET(fd, &rset) ) {
			char buf[1024] = {};
			int r = read(fd, buf, 1024);
			if (r == 0 ) {
				printf("server close\n");
				break;
			}
			if ( r == -1 )
				break;
			printf("recv = %s\n", buf);
		}
	}

	close(fd);
}

