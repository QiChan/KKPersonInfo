#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

int main( void ) {
	int cfd = socket(AF_INET, SOCK_DGRAM, 0);
	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port = htons(9000);
	inet_aton("127.0.0.1", &addr.sin_addr);

	char buf[1024] = {};
	char recvbuf[1024] = {};
	socklen_t len = sizeof addr;
	while ( fgets(buf, 1024, stdin) != NULL ) {
		sendto(cfd, buf, strlen(buf), 0, (struct sockaddr*)&addr, len);
		recvfrom(cfd, recvbuf, 1024, 0, NULL, NULL);
		printf("%s", recvbuf);
		memset(buf, 0x00, 1024);
		memset(recvbuf, 0x00, 1024);
	}
}
