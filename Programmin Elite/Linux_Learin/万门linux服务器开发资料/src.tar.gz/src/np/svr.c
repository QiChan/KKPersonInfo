#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <string.h>
#include <errno.h>

ssize_t readn(int fd, void *buf, size_t count) {
	ssize_t left = count;
	char *p = (char*)buf;
	ssize_t nread;

	while ( left > 0 ) {
		nread = read(fd, p, left);
		if ( nread == -1 ) {
			if ( errno == EINTR )
				continue;
			return -1;
		} else if ( nread == 0 ) {
			return count - left;
		}
		p = p + nread;
		left = left - nread;
	}

	return count;
}

ssize_t writen(int fd, const void *buf, size_t count) {
	int left = count;
	char *p = (char*)buf;
	int nwrite;

	while ( left > 0 ) {
		nwrite = write(fd, p, left);
		if ( nwrite == -1 ) {
			if ( errno == EINTR )
				continue;
			return -1;
		}
		left = left - nwrite;
		p  = p + nwrite;
	}

	return count;
}

typedef struct msg {
	int len;
	char buf[1024];
}msg_t;

int main( void ) {
	int lfd = socket(AF_INET, SOCK_STREAM, 0);
	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port   = htons(9000);
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	int r = bind(lfd, (struct sockaddr*)&addr, sizeof(addr));
	printf("bind error:%s\n", strerror(errno));

	r = listen(lfd, SOMAXCONN);
	printf("listen error:%s\n", strerror(errno));

	int newfd = accept(lfd, NULL, NULL);
	
	while ( 1 ) {
		msg_t mymsg = {};
		int len;
		r = readn(newfd, &len, sizeof(len));
		if ( r <= 0 ) {
			printf("对方已关闭\n");
			break;
		}
		mymsg.len = ntohl(len);
		r = readn(newfd, mymsg.buf, mymsg.len);
		if ( r <= 0 ) {
			printf("对方已关闭\n");
			break;
		}
		printf("recv = %s\n", mymsg.buf);
		writen(newfd, &len, sizeof(len));
		writen(newfd, mymsg.buf, mymsg.len);
	}

	close(newfd);
	close(lfd);
}

