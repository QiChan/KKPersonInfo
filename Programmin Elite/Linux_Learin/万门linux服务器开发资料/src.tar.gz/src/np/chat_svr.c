#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>

typedef struct client {
	int fd;
	char nick_name[32];
}client_t;

typedef struct node {
	client_t c;
	struct node *prev;
	struct node *next;
}node_t;

node_t *head = NULL;

void list_init( void ) {
	head = malloc(sizeof(node_t));
	head->next = head;
	head->prev = head;
}

void list_insert(const client_t *pc) {
	node_t *new_node = malloc(sizeof(node_t));
	new_node->c = *pc;
	new_node->prev = head->prev;
	new_node->next = head;
	head->prev->next = new_node;
	head->prev = new_node;
}

void send_all(const char *msg) {
	node_t *p = head->next;
	
	while ( p != head ) {
		write(p->c.fd, msg, strlen(msg));
		p = p->next;
	}
}

void list_erase(int fd) {
	node_t *p = head->next;
	
	while ( p != head ) {
		if ( p->c.fd == fd ) {
			p->prev->next = p->next;
			p->next->prev = p->prev;
			break;
		}
		p = p->next;
	}
}

void *routine(void *arg) {
	int nfd = *(int*)arg;
	free(arg);

	char *wel = "welcome to chat\n";
	write(nfd, wel, strlen(wel));
	client_t c;
	char *nick = "nick:";
	write(nfd, nick, strlen(nick));
	read(nfd, c.nick_name, 32);

	c.fd = nfd;
	list_insert(&c);

	struct sockaddr_in addr;
	socklen_t len = sizeof(addr);
	getpeername(nfd, (struct sockaddr*)&addr, &len);
	char buf[1024];
	sprintf(buf, "%s online\n", inet_ntoa(addr.sin_addr));
	send_all(buf);

	while ( 1 ) {
		memset(buf, 0x00, sizeof buf);
		int r = read(nfd, buf, sizeof buf);
		if ( r <= 0 )
			break;
		send_all(buf);
	}
	list_erase(nfd);
	sprintf(buf, "%s offline\n", inet_ntoa(addr.sin_addr));	
	send_all(buf);
}

int main( void ) {
	list_init();
	
	int lfd = socket(AF_INET, SOCK_STREAM, 0);	
	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port   = htons(8000);
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	int r = bind(lfd, (struct sockaddr*)&addr, sizeof(addr));
	if ( r == -1 ) perror("bind"),exit(0);
	r = listen(lfd, 10);
	if ( r == -1 ) perror("listen"),exit(0);
	
	while ( 1 ) {
		int nfd = accept(lfd, NULL, NULL);
		if ( nfd == -1 ) continue;
		pthread_t tid;
		int *p = malloc(sizeof(int));
		*p = nfd;
		pthread_create(&tid, NULL, routine, p);
		pthread_detach(tid);
	}
	
}

