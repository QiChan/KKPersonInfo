#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

int main( void ) {
	int sfd = socket(AF_INET, SOCK_DGRAM, 0);
	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port = htons(9000);
	inet_aton("127.0.0.1", &addr.sin_addr);
	int r = bind(sfd, (struct sockaddr*)&addr, sizeof(addr));
	if ( r == -1 ) perror("bind"),exit(1);

	while ( 1 ) {
		char buf[1024] = {};
		struct sockaddr_in peeraddr;
		socklen_t len = sizeof(peeraddr);
		int r = recvfrom(sfd, buf, 1024, 0, (struct sockaddr*)&peeraddr, &len);
		if ( r == -1 ) perror("recvfrom"),exit(1);
		if ( r > 0 ) {
			sendto(sfd, buf, r, 0, (struct sockaddr*)&peeraddr, sizeof(peeraddr));
		}
	}
}
