#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

int main( void ) {
	int cfd = socket(AF_INET, SOCK_DGRAM, 0);
	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port = htons(9000);
	inet_aton("192.168.29.255", &addr.sin_addr);

	int op = 1;
	setsockopt(cfd, SOL_SOCKET, SO_REUSEADDR, &op, sizeof op);
	int r = bind(cfd, (struct sockaddr*)&addr, sizeof addr);
	if ( r == -1 ) perror("bind"),exit(1);

	char buf[1024] = {};
	while ( 1 ) {
		recv(cfd, buf, 1024, 0);
		printf("%s", buf);
		memset(buf, 0x00, sizeof buf);
		sleep(2);
	}
}

