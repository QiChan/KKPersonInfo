#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

int main( void ) {
	int cfd = socket(AF_INET, SOCK_DGRAM, 0);
	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port = htons(9000);
	inet_aton("192.168.29.255", &addr.sin_addr);

	int op = 1;
	setsockopt(cfd, SOL_SOCKET, SO_BROADCAST, &op, sizeof op);

	char msg[100] = "我是广播\n";
	int i = 1;
	while ( 1 ) {
		sprintf(msg, "我是广播:%d\n", i++);
		sendto(cfd, msg, strlen(msg), 0, (struct sockaddr*)&addr, sizeof addr);
		sleep(1);
	}
	
}

