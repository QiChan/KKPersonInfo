#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/epoll.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

int main( void ) {
	int lfd = socket(AF_INET, SOCK_STREAM, 0);
	
	int op = 1;
	setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &op, sizeof(op));
	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port = htons(9090);
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	int r = bind(lfd, (struct sockaddr*)&addr, sizeof(addr));
	if ( r == -1 ) perror("bind"),exit(1);
	listen(lfd, SOMAXCONN);

	int epfd = epoll_create(10);
	if ( epfd == -1 ) perror("epoll_create"),exit(1);

	struct epoll_event ev;
	ev.events = EPOLLIN;
	ev.data.fd = lfd;
	epoll_ctl(epfd, EPOLL_CTL_ADD, lfd, &ev);

	struct epoll_event evs[100];
	for ( ; ; ) {
		int nready = epoll_wait(epfd, evs, 100, -1);
		int i;
		for (i=0; i<nready; i++) {
			if ( evs[i].data.fd == lfd ) {
				int cfd = accept(lfd, NULL, NULL);

				int flag = fcntl(cfd, F_GETFL, 0);
				flag |= O_NONBLOCK;
				fcntl(cfd, F_SETFL, flag);

				ev.events = EPOLLIN | EPOLLET;
				ev.data.fd = cfd;
				epoll_ctl(epfd, EPOLL_CTL_ADD, cfd, &ev);
			} else {
				int cfd = evs[i].data.fd;
				char buf[1024] = {};
			
				while ( (r=read(cfd, buf, 1024)) > 0 ) {
					write(cfd, buf, r);
				}
				if ( r == 0 ) {
					epoll_ctl(epfd, EPOLL_CTL_DEL, cfd, NULL);
					close(cfd);
				}
			}
		}
	}
}


