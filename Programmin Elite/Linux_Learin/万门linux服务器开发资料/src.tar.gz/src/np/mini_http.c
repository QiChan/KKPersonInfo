#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>

int readline(int cfd, char buf[], int len) {
	int i;
	for (i=0; i<len; i++) {
		int r = read(cfd, buf+i, 1);
		if ( r <= 0 )
			break;
		if ( buf[i] == '\n' )
			break;
	}
	buf[++i] = 0;
	
	return i;
}

void do_get(int cfd, char *name) {
	char path[1024];
	sprintf(path, "/html%s", name);

	int fd = open(path, O_RDONLY);
	if ( fd == -1 ) {
		char *err = "404 page not found";
		write(cfd, err, strlen(err));
		return;
	}
	
	char buf[1024];
	while ( 1 ) {
		memset(buf, 0x00, 1024);
		int r= read(fd, buf, 1023);
		if ( r <= 0 )
			break;
		write(cfd, buf, r);
	}
	
	close(fd);
}

int main( void ) {
	int lfd = socket(AF_INET, SOCK_STREAM, 0);
	int op = 1;
	setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &op, sizeof op);
	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port = htons(80);
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	int r = bind(lfd, (struct sockaddr*)&addr, sizeof(addr));
	if ( r == -1 ) perror("bind"),exit(1);

	listen(lfd, 100);

	for (; ; ) {
		int cfd = accept(lfd, NULL, NULL);
		for ( ; ; ) {
			char buf[1024] = {};
			r = readline(cfd, buf, 1023);
			printf("r=%d, buf=%s", r, buf);
			if ( r <= 2 ) {
				break;
			}
			if ( strncasecmp(buf, "GET", 3) == 0 ) {
				char *p = strchr(buf, '/');
				char *q = strchr(p, ' ');
				*q = 0;
				do_get(cfd, p);
			}
		}
		
		close(cfd);
	}
}

